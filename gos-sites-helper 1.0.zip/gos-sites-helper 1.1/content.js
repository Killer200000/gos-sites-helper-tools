// Пример обработки страницы для изменения каких-либо элементов
console.log('Gos Sites Helper active on:', window.location.href);

// Пример: изменение фона страницы
document.body.style.backgroundColor = '#f0f0f0';

// Также здесь можно добавлять код для взаимодействия с сайтом
