chrome.runtime.onInstalled.addListener(() => {
  console.log('Gos Sites Helper installed');
});

// Можно использовать события, если требуется выполнять действия в фоновом режиме
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'check') {
    console.log('Received check request');
    sendResponse({ status: 'ok' });
  }
});
