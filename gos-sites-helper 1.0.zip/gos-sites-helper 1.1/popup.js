document.getElementById('checkButton').addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'check' }, (response) => {
    alert('Status: ' + response.status);
  });
});
